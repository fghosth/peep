package base

import (
	"bytes"
	"fmt"
	"github.com/zhuxiujia/GoMybatis"
	"os"
	"reflect"
	"testing"
)

var (
	xmlPath = "/Users/derek/project/demo/peep/mysqlxml/"
)

func TestBybatis(t *testing.T) {
	err := os.Mkdir(xmlPath, os.ModePerm)
	if err != nil {
		fmt.Println(err)
	}
	beans := make(map[string]interface{})
	beans[new(BalanceReports).TableName()] = *new(BalanceReports)
	beans[new(BomMaterial).TableName()] = *new(BomMaterial)
	beans[new(CallbackTask).TableName()] = *new(CallbackTask)
	beans[new(CostReports).TableName()] = *new(CostReports)
	beans[new(CountTask).TableName()] = *new(CountTask)
	beans[new(ReciptData).TableName()] = *new(ReciptData)
	beans[new(SalesData).TableName()] = *new(SalesData)
	for k, v := range beans {
		xmlfile := xmlPath + reflect.TypeOf(v).Name() + "Mapper.xml"
		xml := GoMybatis.CreateXml(k, v)
		xml = bytes.Replace(xml, []byte("</mapper>"), []byte(XML_TMP), -1)
		GoMybatis.OutPutXml(xmlfile, xml)
	}
}

const (
	XML_TMP = `
<!-- =============================！！！！以上内容不要修改！！！！！================================================= -->
<!--模板标签: columns wheres sets 支持逗号,分隔表达式，*?* 为判空表达式-->
<!--插入模板:默认id="insertTemplate,test="field != null",where自动设置逻辑删除字段,支持批量插入" -->
<insertTemplate id="Insert" />
<!--查询模板:默认id="selectTemplate,where自动设置逻辑删除字段-->
<selectTemplate id="FindByID" wheres="id?id = #{id}" />
<!--更新模板:默认id="updateTemplate,set自动设置乐观锁版本号-->
<updateTemplate id="UpdataByID"  wheres="id?id = #{id}" />
<!--删除模板:默认id="deleteTemplate,where自动设置逻辑删除字段-->
<deleteTemplate id="DeleteByID" wheres="id?id= #{id}" />
<!--批量插入: 因为上面已经有id="insertTemplate" 需要指定id -->
<insertTemplete id="InsertBatch"/>
<!--统计模板:-->
<!--	<selectTemplete id="selectCountTemplete" columns="count(*)" wheres="reason?reason = #{reason}"/>-->
</mapper>
`
)
