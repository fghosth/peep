package base

import "time"

type BalanceReports struct {
	Id                      uint64    `json:"id" orm:"id"  gm:"id"`         // [primary]
	ProductId               uint64    `json:"product_id" orm:"product_id" ` // 物料或bom ID
	PartnerId               uint64    `json:"partner_id" orm:"partner_id" `
	CountTypeId             uint64    `json:"count_type_id" orm:"count_type_id" `                         // 统计纬度id，门店或成本中心id
	TaskId                  uint64    `json:"task_id" orm:"task_id" `                                     // 关联账期任务id
	Category                uint32    `json:"category" orm:"category" `                                   // 1:bom商品，2：物料商品
	Scost                   float64   `json:"scost" orm:"scost" `                                         // 上期成本
	AllScost                float64   `json:"all_scost" orm:"all_scost" `                                 // 本期期初金额
	PurchaseQty             float64   `json:"purchase_qty" orm:"purchase_qty" `                           // 采购收货数量
	PurchaseAmount          float64   `json:"purchase_amount" orm:"purchase_amount" `                     // 采购收货金额
	PurchaseShare           float64   `json:"purchase_share" orm:"purchase_share" `                       // 采购费用分摊金额
	InvoiceBalancingAdjust  float64   `json:"invoice_balancing_adjust" orm:"invoice_balancing_adjust" `   // 发票差额调整金额
	PurchaseBalancingAdjust float64   `json:"purchase_balancing_adjust" orm:"purchase_balancing_adjust" ` // 采购收货调整金额
	AllotOut                float64   `json:"allot_out" orm:"allot_out" `                                 // 调拨出数量
	AllotIn                 float64   `json:"allot_in" orm:"allot_in" `                                   // 调拨入数量
	ScrapQty                float64   `json:"scrap_qty" orm:"scrap_qty" `                                 // 报废数量
	BomMaterialScrapQty     float64   `json:"bom_material_scrap_qty" orm:"bom_material_scrap_qty" `       // BOM原料报废数量
	SaleQty                 float64   `json:"sale_qty" orm:"sale_qty" `                                   // 销售数量
	BomMaterialSaleQty      float64   `json:"bom_material_sale_qty" orm:"bom_material_sale_qty" `         // BOM原料销售数量
	BomCreated              float64   `json:"bom_created" orm:"bom_created" `                             // BOM产出数量
	BomMaterialScrapAmount  float64   `json:"bom_material_scrap_amount" orm:"bom_material_scrap_amount" ` // BOM原料报废金额
	BomMaterialSaleAmount   float64   `json:"bom_material_sale_amount" orm:"bom_material_sale_amount" `   // BOM原料销售金额
	DeliveryOut             float64   `json:"delivery_out" orm:"delivery_out" `                           // 配送出库数量
	DeliveryIn              float64   `json:"delivery_in" orm:"delivery_in" `                             // 配送入库数量
	InventoryDiff           float64   `json:"inventory_diff" orm:"inventory_diff" `                       // 盘点损益
	EQTY                    float64   `json:"eQTY" orm:"eQTY" `                                           // 期末数量
	Ecost                   float64   `json:"ecost" orm:"ecost" `                                         // 本期期末金额
	StockQty                float64   `json:"Stock_qty" orm:"Stock_qty" `                                 // 库存数量
	StockCost               float64   `json:"stock_cost" orm:"stock_cost" `                               // 库存成本金额
	CountDiffStockQty       float64   `json:"count_diff_stock_qty" orm:"count_diff_stock_qty" `           // 差异数量
	CountDiffStockCost      float64   `json:"count_diff_stock_cost" orm:"count_diff_stock_cost" `         // 差异金额
	EstimatePrice           float64   `json:"estimate_price" orm:"estimate_price" `                       // 估算成本单价
	EPrice                  float64   `json:"ePrice" orm:"ePrice" `                                       // 当期成本单价
	CreateTime              time.Time `json:"create_time" orm:"create_time" `
	ModifyTime              time.Time `json:"modify_time" orm:"modify_time" `
	DeleteFlag              uint32    `json:"delete_flag" orm:"delete_flag"  gm:"logic"` // [delete_flag]
	Version                 uint64    `json:"version" orm:"version"  gm:"version"`       // [version]
	CountType               uint32    `json:"count_type" orm:"count_type" `              // 统计纬度 1：成本中心，2：门店
}

func (BalanceReports) TableName() string {
	return "balance_reports"
}

type BomMaterial struct {
	Id         uint64    `json:"id" orm:"id" `
	SalesId    uint64    `json:"sales_id" orm:"sales_id" `
	ProductId  uint64    `json:"product_id" orm:"product_id" ` // bom产品id
	MaterialId uint64    `json:"material_id" orm:"material_id" `
	Qty        float64   `json:"qty" orm:"qty" `
	DeleteFlag uint32    `json:"delete_flag" orm:"delete_flag" `
	Version    uint64    `json:"version" orm:"version" `
	CreateTime time.Time `json:"create_time" orm:"create_time" `
	ModifyTime time.Time `json:"modify_time" orm:"modify_time" `
}

func (BomMaterial) TableName() string {
	return "bom_material"
}

type CallbackTask struct {
	Id         uint64    `json:"id" orm:"id" `
	Status     uint32    `json:"status" orm:"status" ` // 1:sending,2:success,3:fail,4.waiting
	CreateTime time.Time `json:"create_time" orm:"create_time" `
	ModifyTime time.Time `json:"modify_time" orm:"modify_time" `
	IsDeleted  uint32    `json:"is_deleted" orm:"is_deleted" `
	Category   uint32    `json:"category" orm:"category" ` // 类型，1：计算任务,
	Code       string    `json:"code" orm:"code" `         // 1.成功 2.失败
	Message    string    `json:"message" orm:"message" `
	RequestId  uint64    `json:"request_id" orm:"request_id" `
	Address    string    `json:"address" orm:"address" `
	DeleteFlag uint32    `json:"delete_flag" orm:"delete_flag" `
	Version    uint64    `json:"version" orm:"version" `
}

func (CallbackTask) TableName() string {
	return "callback_task"
}

type CostReports struct {
	Id          uint64    `json:"id" orm:"id" `
	ProductId   uint64    `json:"product_id" orm:"product_id" ` // 物料或bom ID
	PartnerId   uint64    `json:"partner_id" orm:"partner_id" `
	CountTypeId uint64    `json:"count_type_id" orm:"count_type_id" ` // 统计纬度id，门店或成本中心id
	TaskId      uint64    `json:"task_id" orm:"task_id" `             // 关联任务id
	Category    uint32    `json:"category" orm:"category" `           // 1:bom商品，2：物料商品
	Scost       float64   `json:"scost" orm:"scost" `                 // 期初成本
	Sqty        float64   `json:"sqty" orm:"sqty" `                   // 期初数量
	Ecost       float64   `json:"ecost" orm:"ecost" `                 // 期末成本
	Eqty        float64   `json:"eqty" orm:"eqty" `                   // 期末数量
	CreateTime  time.Time `json:"create_time" orm:"create_time" `
	ModifyTime  time.Time `json:"modify_time" orm:"modify_time" `
	DeleteFlag  uint32    `json:"delete_flag" orm:"delete_flag" `
	Version     uint64    `json:"version" orm:"version" `
	CountType   uint32    `json:"count_type" orm:"count_type" ` // 统计纬度 1：成本中心，2：门店
}

func (CostReports) TableName() string {
	return "cost_reports"
}

type CountTask struct {
	Id          uint64    `json:"id" orm:"id" `
	RequestId   uint64    `json:"request_id" orm:"request_id" `
	Stime       time.Time `json:"stime" orm:"stime" `
	Etime       time.Time `json:"etime" orm:"etime" `
	Status      uint32    `json:"status" orm:"status" ` // 1:未执行，2：执行中，3：已完成 4：失败，已放弃
	Reason      string    `json:"reason" orm:"reason" `
	Cid         uint64    `json:"cid" orm:"cid" ` // 计算纬度id，成本中心ID，门店id
	IsDeleted   uint32    `json:"is_deleted" orm:"is_deleted" `
	CreateTime  time.Time `json:"create_time" orm:"create_time" `
	ModifyTime  time.Time `json:"modify_time" orm:"modify_time" `
	RequestData string    `json:"request_data" orm:"request_data" ` // 此次提交任务的json数据
	Category    uint32    `json:"category" orm:"category" `         // 1为物料任务，2为bom商品任务 3:重新计算物料  4：重新计算bom
	CountType   string    `json:"count_type" orm:"count_type" `     // 计算纬度 成本中心，门店，公司等
	Days        uint64    `json:"days" orm:"days" `                 // 重新计算时持续的天数
	DeleteFlag  uint32    `json:"delete_flag" orm:"delete_flag" `
	Version     uint64    `json:"version" orm:"version" `
	PartnerId   uint64    `json:"partner_id" orm:"partner_id" ` // 租户id
}

func (CountTask) TableName() string {
	return "count_task"
}

type ReciptData struct {
	Id           uint64    `json:"id" orm:"id" `
	Category     int32     `json:"category" orm:"category" `           // 1:采购收货单据,2:采购退货单据,3:直送收货单,4:直送退货单,5:采购费用分摊金额调价单,6:发票差额调整金额调价单，7：采购收货调整金额调价单0:所有，1:采购收货单据,2:采购退货单据,3:直送收货单,4:直送退货单,5:采购费用分摊金额调价单,6:发票差额调整金额调价单，7：采购收货调整金额调价单
	MaterialId   uint64    `json:"material_id" orm:"material_id" `     // 物料id
	Qty          float64   `json:"qty" orm:"qty" `                     // 数量
	Price        float64   `json:"price" orm:"price" `                 // 资金
	SorteId      uint64    `json:"sorte_id" orm:"sorte_id" `           // 门店id
	CostcenterId uint64    `json:"costcenter_id" orm:"costcenter_id" ` // 成本中心id
	Unit         string    `json:"unit" orm:"unit" `                   // 单位
	CreateTime   time.Time `json:"create_time" orm:"create_time" `
	ModifyTime   time.Time `json:"modify_time" orm:"modify_time" `
	Rtime        time.Time `json:"rtime" orm:"rtime" `         // 单据上的确认时间
	ReciptId     uint64    `json:"recipt_id" orm:"recipt_id" ` // 单据id
	RequestId    uint64    `json:"request_id" orm:"request_id" `
	PartnerId    uint64    `json:"partner_id" orm:"partner_id" `
	Status       string    `json:"status" orm:"status" ` // 订单终态
	DeleteFlag   uint32    `json:"delete_flag" orm:"delete_flag" `
	Version      uint64    `json:"version" orm:"version" `
}

func (ReciptData) TableName() string {
	return "recipt_data"
}

type SalesData struct {
	Id           uint64    `json:"id" orm:"id" `
	SorteId      uint64    `json:"sorte_id" orm:"sorte_id" `
	CostcenterId uint64    `json:"costcenter_id" orm:"costcenter_id" `
	PartnerId    uint64    `json:"partner_id" orm:"partner_id" `
	ProductId    uint64    `json:"product_id" orm:"product_id" `
	SaleId       uint64    `json:"sale_id" orm:"sale_id" ` // 销售单id
	Rtime        time.Time `json:"rtime" orm:"rtime" `     // 确认时间
	Qty          float64   `json:"qty" orm:"qty" `         // 销售数量
	RequestId    uint64    `json:"request_id" orm:"request_id" `
	DeleteFlag   uint32    `json:"delete_flag" orm:"delete_flag" `
	Version      uint64    `json:"version" orm:"version" `
	CreateTime   time.Time `json:"create_time" orm:"create_time" `
	ModifyTime   time.Time `json:"modify_time" orm:"modify_time" `
}

func (SalesData) TableName() string {
	return "sales_data"
}
