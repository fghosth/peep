
package base

import (
	"database/sql"
	"errors"
	_ "github.com/go-sql-driver/mysql"
	"github.com/zhuxiujia/GoMybatis"
	"io/ioutil"
	"sync"
)

var (
	once sync.Once
	dbBase *DBBase
	defaultMaxIdleConns = 10
	defaultMaxOpenConns = 50
)

type DBBase struct{
	engine *GoMybatis.GoMybatisEngine
	mysqlUri string
	db *sql.DB
	opt Option
}

type Option struct{
	MaxIdleConns int
	MaxOpenConns int
	SetLogEnable bool //是否自定义日志系统
	LogFun func(msg []byte)//自定义日志
}

type DBOption func(option *Option)


func GetDBBase()(*DBBase,error){
	if dbBase==nil || dbBase.db==nil {
		return nil,errors.New("DBBase 未初始化，请先调用NewDBBase")
	}
	return dbBase,nil
}


func NewDBBase(mysqlUri string, opt ...func(option *Option))(*DBBase,error) {
	if mysqlUri == "" {
		return nil,errors.New("数据库链接地址错误")
	}
	var err error
	once.Do(func() {
		option:=Option{
			MaxIdleConns: defaultMaxIdleConns,
			MaxOpenConns: defaultMaxOpenConns,
			SetLogEnable: false,
			LogFun: func(msg []byte) {},
		}
		for _, f := range opt {
			f(&option)
		}
		engine:=GoMybatis.GoMybatisEngine{}.New()
		dbBase=&DBBase{
			engine:&engine,
			mysqlUri:mysqlUri,
			opt: option,
		}
		dbBase.db, err = dbBase.engine.Open("mysql", mysqlUri) //此处请按格式填写你的mysql链接，这里用*号代替
		if err!=nil {
			return
		}
		dbBase.db.SetMaxIdleConns(dbBase.opt.MaxIdleConns)
		dbBase.db.SetMaxOpenConns(dbBase.opt.MaxOpenConns)
		//自定义日志实现
		dbBase.engine.SetLogEnable(dbBase.opt.SetLogEnable)
		dbBase.engine.SetLog(&GoMybatis.LogStandard{
			PrintlnFunc: func(messages []byte) {
				dbBase.opt.LogFun(messages)
			},
		})
	})
	if err != nil {
		return nil,err
	}
	return dbBase,nil
}
//返回db链接以便自定义
func (this DBBase)GetDB()*sql.DB{
	return this.db
}
//返回engin以便自定义
func (this DBBase)GetEngin()*GoMybatis.GoMybatisEngine{
	return this.engine
}

func (this *DBBase)WriteMapper(obj interface{},xmlfile string)error{
	//读取mapper xml文件
	bytes, err := ioutil.ReadFile(xmlfile)
	if err!=nil {
		return err
	}
	//设置对应的mapper xml文件
	this.engine.WriteMapperPtr(obj, bytes)
	return nil
}


//设置最大空闲连接数
func WithMaxIdleConns(num int) DBOption {
	return func(option *Option) {
		option.MaxIdleConns = num
	}
}
//设置最大连接数
func WithMaxOpenConns(num int) DBOption {
	return func(option *Option) {
		option.MaxOpenConns = num
	}
}
//设置是否使用自定义日志
func WithSetLogEnable(flag bool) DBOption {
	return func(option *Option) {
		option.SetLogEnable = flag
	}
}
//设置自定义日志方法
func WithLogFun(f func(msg []byte)) DBOption {
	return func(option *Option) {
		option.LogFun= f
	}
}

